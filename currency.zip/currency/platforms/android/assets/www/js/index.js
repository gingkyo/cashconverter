
var isSetHome=false;
var app = {
  // Application Constructor
  initialize: function () {
    this.bindEvents();
  },
  bindEvents: function () {
    document.addEventListener('deviceready', this.onDeviceReady, false);
  },
  onDeviceReady: function () {
    //document.addEventListener("online", onOnline, false);
    //document.addEventListener("offline", onOffline, false);
    document.getElementById("homePageMode").addEventListener('click', app.changePage, false);
    document.getElementById("convertMode").addEventListener('click', app.changePage, false);
    document.getElementById("holidayMode").addEventListener('click', app.changePage, false);
    document.getElementById("settingsMode").addEventListener('click', app.changePage, false);
    document.getElementById("setHome").addEventListener('click', app.homeSetter, false);
    document.getElementById("downloadXRate").addEventListener('click', app.xhrFavouritePrice, false);
    document.getElementById("savedXrates").addEventListener('click', app.queryLatestPrices, false);
    document.getElementById('setConvertTo').addEventListener('click',app.getCountryListDB,false);
    document.getElementById("myHome").textContent=localStorage.getItem("homeCountry");
    app.createDatabase();
    navigator.geolocation.getCurrentPosition(app.alertPosition);

  },
  alertPosition:function(position){
    alert("Latitude"+position.coords.latitude+"\nLongitude"+position.coords.longitude);
  },
  changePage :function(e){
    document.getElementById("contentsPanel").style.display="none";
    var mainPage = document.getElementById("mainPage");
    var settingsPage = document.getElementById("settingsPage");
    switch(this.id){
      case 'homePageMode' :
      mainPage.style.display = "block";
      settingsPage.style.display = "none";
      converterPage.style.display="none";
      break;
      case 'convertMode' :
      mainPage.style.display = "none";
      settingsPage.style.display = "block";
      document.getElementById("panelTitle").textContent="Converter";
      break;
      case 'settingsMode':
      mainPage.style.display = "none";
      settingsPage.style.display = "block";
      document.getElementById("panelTitle").textContent="Settings";
      break;
    }
  },
  xhrWeatherRequest:function(e){
    var xhr = new XMLHttpRequest();
    xhr.addEventListener("load", app.alertJSON);
    xhr.open("GET", "http://api.openweathermap.org/data/2.5/weather?lat=35&lon=139&units=metric&appid=06d5c67dade3b87ecd64c03c2228afe8");
    xhr.send();
  },
  alertJSON:function(){
    //var testGet=JSON.parse(this.responseText);
    //var grab=testGet.rates.USD;
    alert(this.responseText);
  },
  homeSetter:function(e){
    isSetHome=true;
    app.getCountryListDB(this);
  },
  setHome : function(e){
    document.getElementById('settingsPage').style.display="block";
    document.getElementById("contentsPanel").style.display = "none";
    document.getElementById('logoBanner').style.display="block";
    document.getElementById('myHome').textContent=this.name;
    localStorage.setItem("homeCountry",this.name);
    localStorage.setItem("homeCurrency",this.id);
    isSetHome=false;
  },
  setConvertCountry:function(e){
    document.getElementById('settingsPage').style.display="block";
    document.getElementById("contentsPanel").style.display = "none";
    document.getElementById('logoBanner').style.display="block";
    document.getElementById('convertTo').textContent=this.name;
    localStorage.setItem("convertToCountry",this.name);
    localStorage.setItem("convertToCurrency",this.id);
  },
  createDatabase: function () {
    var db = window.openDatabase("XrateDB", "1.0", "Exchange Rate Database", 1000);
    db.transaction(this.addCountryTableDB, this.errorDB);
  },
  errorDB: function (err) {
    alert('Something went wrong :(');
    console.log(err);
  },
  checkHomeSet :function(){
    return localStorage.getItem("homeCurrency");
  },
  getCountryListDB: function (e) {
    document.getElementById("logoBanner").style.display="none";
    var db = window.openDatabase("XrateDB", "1.0", "Exchange Rate Database", 1000);
    db.transaction(function (tx) {
      tx.executeSql('SELECT * FROM COUNTRIES', [], app.countryQuerySuccess, app.errorDB);
    }, app.errorDB);
  },
  xhrFavouritePrice :function(e){
    var homeCurr=app.checkHomeSet();
    if(homeCurr){
      var currencyQuery=localStorage.getItem("convertToCurrency");
      var xhr = new XMLHttpRequest();
      xhr.addEventListener("load", app.showConvertRate);
      xhr.open("GET", "https://api.fixer.io/latest?base="+homeCurr+"&symbols="+currencyQuery);
      xhr.send();
    } else {
      alert("Must Set Home First!");
      app.homeSetter(this);
    }
  },
  showConvertRate: function (){
    alert(this.responseText);
    //document.getElementById("currentRate").textContent=this.responseText;
    //document.getElementById("favouriteConversionPanel").style.display="block";
  },
  queryLatestPrices :function(e){
    var db = window.openDatabase("XrateDB", "1.0", "Exchange Rate Database", 1000);
    var homeCurr=app.checkHomeSet();
    if(homeCurr){
      db.transaction(function (tx) {
        tx.executeSql('SELECT * FROM COUNTRIES WHERE CURRENCY != ?', [homeCurr], app.currencyListSuccess, app.errorDB);
      }, app.errorDB);
    } else {
      alert("Must Set Home First!");
      app.homeSetter(this);
    }
  },
  currencyListSuccess:function(tx,results){
    var len=results.rows.length;
    var currencyQuery;
    for (i = 0; i < len; i++) {
      var currency = results.rows.item(i).currency;
      currencyQuery+=currency+",";
    }
    app.xhrPriceRequest(currencyQuery);
  },
  xhrPriceRequest:function(currencyQuery){
    var homeCurr=localStorage.getItem("homeCurrency");
    var xhr = new XMLHttpRequest();
    xhr.addEventListener("load", app.alertJSON);
    xhr.open("GET", "https://api.fixer.io/latest?base="+homeCurr+"&symbols="+currencyQuery);
    xhr.send();
  },
  countryQuerySuccess: function (tx, results) {
    document.getElementById('settingsPage').style.display="none";
    document.getElementById("contentsPanel").style.display = "block";
    var len = results.rows.length;

    //document.getElementById("databaseTable").style.display = "block";
    var tableBody = document.getElementById("databaseTable").getElementsByTagName('tbody')[0];

    while (tableBody.firstChild) {
      tableBody.removeChild(tableBody.firstChild);
    }
    for (i = 0; i < len; i++) {
      var country=results.rows.item(i).country;
      var currency = results.rows.item(i).currency;

      var row = tableBody.insertRow(-1);  // inset at end
      var cell0 = row.insertCell(0);
      var cell1 = row.insertCell(1);

      cell0.textContent = country;
      cell1.textContent = currency;

      row.name=country;
      row.id=currency;
      if(isSetHome){
        row.addEventListener("click",app.setHome,false);
      } else{
        row.addEventListener("click",app.setConvertCountry,false);
      }
    }
  },
  addCountryTableDB: function(tx){
    var data ={"countries":[
      {"country":"Australia","currency":"AUD"},
      {"country":"Bulgaria","currency":"BGN"},
      {"country":"Brazil","currency":"BRL"},
      {"country":"Canada","currency":"CAD"},
      {"country":"Switzerland","currency":"CHF"},
      {"country":"China","currency":"CNY"},
      {"country":"Czech Republic","currency":"CZK"},
      {"country":"Denmark","currency":"DKK"},
      {"country":"Euro","currency":"EUR"},
      {"country":"United Kingdom","currency":"GBP"},
      {"country":"Hong Kong","currency":"HKD"},
      {"country":"Croatia","currency":"HRK"},
      {"country":"Hungary","currency":"HUF"},
      {"country":"Indonesia","currency":"IDR"},
      {"country":"Israel","currency":"ILS"},
      {"country":"India","currency":"INR"},
      {"country":"Japan","currency":"JPY"},
      {"country":"South Korea","currency":"KRW"},
      {"country":"Mexico","currency":"MXN"},
      {"country":"Malaysia","currency":"MYR"},
      {"country":"Norway","currency":"NOK"},
      {"country":"New Zealand","currency":"NZD"},
      {"country":"Phillipines","currency":"PHP"},
      {"country":"Poland","currency":"PLN"},
      {"country":"Romania","currency":"RON"},
      {"country":"Russia","currency":"RUB"},
      {"country":"Swedish","currency":"SEK"},
      {"country":"Singapore","currency":"SGD"},
      {"country":"Thailand","currency":"THB"},
      {"country":"Turkey","currency":"TRY"},
      {"country":"USA","currency":"USD"},
      {"country":"South Africa","currency":"ZAR"}
    ]};
    tx.executeSql('DROP TABLE IF EXISTS COUNTRIES');
    tx.executeSql('CREATE TABLE IF NOT EXISTS COUNTRIES (country UNIQUE,currency)');
    for(var i=0;i<data.countries.length;i++){
      var country=data.countries[i].country;
      var currency=data.countries[i].currency;
      tx.executeSql('INSERT INTO COUNTRIES (country, currency) VALUES (?,?)',[country,currency]);
    }
  }
};
app.initialize();
